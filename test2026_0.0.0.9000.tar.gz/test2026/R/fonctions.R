#' Fonction pair de BF
#'
#' Description ...
#'
#'@author Bineta FAYE
#'
#'@param n Entier à tester
#'@return Vrai si n est est pair et faux sinon
#'@export
#'
#' @examples
#' pair_BF(3)
#' pair_BF(2)

pair_BF<-function(n) {

    return(n %% 2 == 0)
  }



#' Fonction tracant un cercle pour un rayon donné de BF
#'

#'
#'@author Bineta FAYE
#'
#'@param R le rayon du cercle
#'@return graphique du cercle
#'@export
#'
#' @examples
#' cercle_BF(1)
#' cercle_BF(2)

cercle_BF<-function(R) {

  # Coordonnées du cercle
  theta <- seq(0, 2*pi, length.out = 200)
  x <- R * cos(theta)
  y <- R * sin(theta)

  # Tracé
  plot(x, y, type = "l", asp = 1, col = "blue", lwd = 2,
       main = paste("Cercle de rayon",R))
}



#' nouvelle fonction
#' taux

#'@author Bineta
#'
#'@export
#'
#'@examples
#'taux_survie(df,'sex')
#'taux_survie(df,'passengerClass')

taux_survie <- function(data,variable) {
  library(dplyr)
  data %>%
    group_by(data[,variable]) %>%
    summarize(TauxSurvie = sum(survived == "yes") / n())
}
